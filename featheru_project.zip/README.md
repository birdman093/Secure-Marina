# GCP_FullApp
Full Application built on GCP using Google Datastore with OAuth
