local = "http://127.0.0.1:8000"
production = "https://marina-388119.ue.r.appspot.com"
baseurl = production

boatstablename = "boats"
loadtablename = "loads"
usertablename = "users"